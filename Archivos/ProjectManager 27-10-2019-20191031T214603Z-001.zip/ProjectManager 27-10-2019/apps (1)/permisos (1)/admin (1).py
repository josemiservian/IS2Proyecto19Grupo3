from django.contrib import admin
from .models import Permiso

# Register your models here.
admin.site.register(Permiso)