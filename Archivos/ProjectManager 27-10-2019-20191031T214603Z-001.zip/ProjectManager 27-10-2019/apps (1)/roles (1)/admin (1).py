from django.contrib import admin
from .models import Rol

# Register your models here.
admin.site.register(Rol)