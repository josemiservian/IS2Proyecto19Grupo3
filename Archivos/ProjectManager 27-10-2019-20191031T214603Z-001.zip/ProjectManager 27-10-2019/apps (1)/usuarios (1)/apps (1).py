"""Configuracion app usuario."""

from django.apps import AppConfig


class UsersConfig(AppConfig):
    """User app config."""

    name = 'usuarios'
    verbose_name = 'Usuarios'
