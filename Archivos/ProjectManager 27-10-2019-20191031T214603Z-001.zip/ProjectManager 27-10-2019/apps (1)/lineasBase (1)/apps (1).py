from django.apps import AppConfig


class LineasbaseConfig(AppConfig):
    name = 'lineasBase'
